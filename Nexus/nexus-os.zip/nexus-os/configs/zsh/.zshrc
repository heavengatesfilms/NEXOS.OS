# ============================================================
#  NEXUS OS — Zsh Configuration
#  ~/.zshrc
# ============================================================

# ── ZINIT ────────────────────────────────────────────────────
ZINIT_HOME="${XDG_DATA_HOME:-${HOME}/.local/share}/zinit/zinit.git"
if [[ ! -d "$ZINIT_HOME" ]]; then
  mkdir -p "$(dirname $ZINIT_HOME)"
  git clone https://github.com/zdharma-continuum/zinit.git "$ZINIT_HOME"
fi
source "${ZINIT_HOME}/zinit.zsh"

# Plugins
zinit light zsh-users/zsh-autosuggestions
zinit light zsh-users/zsh-syntax-highlighting
zinit light zsh-users/zsh-history-substring-search
zinit light Aloxaf/fzf-tab

# ── HISTORY ──────────────────────────────────────────────────
HISTSIZE=10000
SAVEHIST=10000
HISTFILE=~/.zsh_history
setopt HIST_IGNORE_DUPS
setopt HIST_IGNORE_SPACE
setopt SHARE_HISTORY
setopt APPEND_HISTORY

# ── COMPLETION ───────────────────────────────────────────────
autoload -Uz compinit && compinit
zstyle ':completion:*' matcher-list 'm:{a-z}={A-Za-z}'
zstyle ':completion:*' list-colors "${(s.:.)LS_COLORS}"
zstyle ':completion:*' menu no
zstyle ':fzf-tab:complete:cd:*' fzf-preview 'eza --tree --color=always $realpath 2>/dev/null'
zstyle ':fzf-tab:complete:__zoxide_z:*' fzf-preview 'eza --tree --color=always $realpath 2>/dev/null'

# ── KEYBINDS ─────────────────────────────────────────────────
bindkey '^[[A' history-substring-search-up
bindkey '^[[B' history-substring-search-down
bindkey '^[[H' beginning-of-line
bindkey '^[[F' end-of-line
bindkey '^[[3~' delete-char

# ── ALIASES — Navigation ─────────────────────────────────────
alias ls='eza --icons --group-directories-first'
alias ll='eza -la --icons --group-directories-first --git'
alias lt='eza --tree --icons --level=2'
alias cat='bat --theme=base16'
alias grep='rg'
alias find='fd'
alias vim='nvim'
alias v='nvim'
alias cd='z'

# ── ALIASES — Git ────────────────────────────────────────────
alias g='git'
alias gs='git status'
alias ga='git add'
alias gc='git commit'
alias gp='git push'
alias gl='git log --oneline --graph --color'
alias gd='git diff'

# ── ALIASES — System ─────────────────────────────────────────
alias update='sudo pacman -Syu'
alias install='sudo pacman -S'
alias remove='sudo pacman -Rns'
alias search='pacman -Ss'
alias clean='sudo pacman -Sc'
alias orphans='sudo pacman -Rns $(pacman -Qtdq)'

# ── ALIASES — NEXUS OS ───────────────────────────────────────
alias nexus-update='sudo pacman -Syu && yay -Syu'
alias nexus-logs='journalctl -xe'
alias nexus-services='systemctl list-units --type=service --state=running'
alias nexus-ports='ss -tulpn'
alias nexus-top='btop'

# ── ALIASES — Cybersecurity ──────────────────────────────────
alias scan='nmap -sV -sC'
alias portscan='nmap -p- --min-rate 5000'
alias myip='curl ifconfig.me'
alias localip="ip -4 addr | grep -oP '(?<=inet\s)\d+(\.\d+){3}'"
alias vpn-up='sudo systemctl start wg-quick@wg0'
alias vpn-down='sudo systemctl stop wg-quick@wg0'
alias torsocks='torsocks'

# ── FZF ──────────────────────────────────────────────────────
export FZF_DEFAULT_COMMAND='fd --type f --hidden --follow --exclude .git'
export FZF_DEFAULT_OPTS="
  --color=bg+:#0a1620,bg:#020609,spinner:#00c8f0,hl:#00ff9d
  --color=fg:#b0d8e8,header:#00c8f0,info:#00ff9d,pointer:#00c8f0
  --color=marker:#00ff9d,fg+:#e0f8ff,prompt:#00c8f0,hl+:#00c8f0
  --border rounded
  --prompt '󰍉 '
  --pointer '▶'
  --marker '✓'
"
export FZF_CTRL_T_COMMAND="$FZF_DEFAULT_COMMAND"
source <(fzf --zsh)

# ── ZOXIDE ───────────────────────────────────────────────────
eval "$(zoxide init zsh)"

# ── STARSHIP PROMPT ──────────────────────────────────────────
eval "$(starship init zsh)"

# ── ENV ──────────────────────────────────────────────────────
export EDITOR=nvim
export VISUAL=nvim
export BROWSER=brave
export TERM=xterm-256color
export PATH="$HOME/.local/bin:$PATH"
export PATH="$HOME/go/bin:$PATH"
export GOPATH="$HOME/go"

# ── FASTFETCH ON NEW TERMINAL ─────────────────────────────────
# Only show on interactive shells, not in nvim terminals
if [[ -z "$NVIM" && -z "$TMUX" ]]; then
  fastfetch
fi
